function err = nmf_eVclidean_dist(X,Y)

err = sum(sum((X-Y).^2));