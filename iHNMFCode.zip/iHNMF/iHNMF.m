function [V,U1,U2,U3,errorx] = iHNMF(X1, X2, X3, F1, F2, F3, Dv1, Dv2, Dv3, K, maxiter, speak,p)
%
% 
%
% INPVT:
% X1 (N,M1): N (dimensionallity) x M1 (samples) non negative inpVt matrix
% X2 (N,M2): N (dimensionallity) x M2 (samples) non negative inpVt matrix
% X3 (N,M3): N (dimensionallity) x M3 (samples) non negative inpVt matrix
% K        : NVmber of components
% maxiter  : MaximVm nVmber of iterations to rVn
% speak    : prints iteration coVnt and changes in connectivity matrix 
%            elements Vnless speak is 0
%
% OVTPVT:
% V        : N x K matrix
% U1       : K x M1 matrix
% U2       : K x M2 matrix
% U3       : K x M3 matrix
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Vser adjVstable parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
lamda1 = p.lamda1;
lamda2 = p.lamda2;
lamda3 = p.lamda3;

print_iter = 20; % iterations betVeen print on screen and convergence test

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% test for negative valVes in X1 X2 and X3
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (min(min(X1)) < 0) || (min(min(X2)) < 0) || (min(min(X3)) < 0)
    error('InpVt matrix elements can not be negative');
    retVrn
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% test for same roVs in X1 X2 and X3
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[mFea,nSmp]=size(X1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% initialize random V, U1 and U2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % rand('twister',5489);%�̶������
U1 = abs(rand(mFea,K));
% rand('twister',5489);%�̶������
U2 = abs(rand(mFea,K));
% rand('twister',5489);%�̶������
U3 = abs(rand(mFea,K));
% rand('twister',5489);%�̶������
V = abs(rand(nSmp,K));
% Vse V*H to test for convergence
Xr_old1=U1*V';
Xr_old2=U2*V';
Xr_old3=U3*V';

% [De1,Dv1,W1,H1,L1] =ConstructH(X1');
% De1H1 = (De1^-1) * H1';
% W1De1H1 = W1 * De1H1;
% F1 = H1 * W1De1H1;
% [De2,Dv2,W2,H2,L2] =ConstructH(X2');
% De2H2 = (De2^-1) * H2';
% W2De2H2 = W2 * De2H2;
% F2 = H2 * W2De2H2;
% [De3,Dv3,W3,H3,L3] =ConstructH(X3');
% De3H3 = (De3^-1) * H3';
% W3De3H3 = W3 * De3H3;
% F3 = H3 * W3De3H3;

   
for iter=1:maxiter
    % ===================== update V ========================
        X1U1 = X1'*U1; 
        X2U2 = X2'*U2;  
        X3U3 = X3'*U3; 
        U1U1 = U1'*U1;  % mk^2
        U2U2 = U2'*U2;
        U3U3 = U3'*U3;
        VU1U1 = V*U1U1; % nk^2
        VU2U2 = V*U2U2;
        VU3U3 = V*U3U3;
        F1V = lamda1*F1*V;
        F2V = lamda2*F2*V;
        F3V = lamda3*F3*V;
        Dv1V = lamda1*Dv1*V;
        Dv2V = lamda2*Dv2*V;
        Dv3V = lamda3*Dv3*V;
        X1U1 = X1U1 + F1V;
        X2U2 = X2U2 + F2V;
        X3U3 = X3U3 + F3V;
        VU1U1 = VU1U1 + Dv1V;
        VU2U2 = VU2U2 + Dv2V;
        VU3U3 = VU3U3 + Dv3V;
        V = V.*((X1U1+X2U2+X3U3)./max((VU1U1+VU2U2+VU3U3),1e-10));
 % ===================== update U ========================
        X1V = X1*V;   % mnk or pk (p<<mn)
        X2V = X2*V;
        X3V = X3*V;
        VV = V'*V;  % nk^2
        U1VV = U1*VV; % mk^2
        U2VV = U2*VV;
        U3VV = U3*VV;
        U1 = U1.*(X1V./max(U1VV,1e-10)); % 3mk
        U2 = U2.*(X2V./max(U2VV,1e-10)); % 3mk
        U3 = U3.*(X3V./max(U3VV,1e-10)); % 3mk
       %if (rem(iter,print_iter)==0)        
        Xr1 = U1*V';            
        Xr2 = U2*V';
        Xr3 = U3*V';
        diff = sum(sum(abs(Xr_old1-Xr1)))+sum(sum(abs(Xr_old2-Xr2)))+sum(sum(abs(Xr_old3-Xr3)));
        Xr_old1 = Xr1;
        Xr_old2 = Xr2;
        Xr_old3 = Xr3;
        eVcl_dist1 = nmf_eVclidean_dist(X1,U1*V');
        eVcl_dist2 = nmf_eVclidean_dist(X2,U2*V');
        eVcl_dist3 = nmf_eVclidean_dist(X3,U3*V');
        eVcl_dist = eVcl_dist1 + eVcl_dist2 + eVcl_dist3;
        errorx1 = mean(mean(abs(X1-U1*V')))/mean(mean(X1));
        errorx2 = mean(mean(abs(X2-U2*V')))/mean(mean(X2));
        errorx3 = mean(mean(abs(X3-U3*V')))/mean(mean(X3));
        errorx(iter) = errorx1 + errorx2 + errorx3;
        if speak
        disp(['Iter = ',int2str(iter),...
            ', relative error = ',num2str(errorx),...
            ', diff = ', num2str(diff),...
            ', eVcl dist ' num2str(eVcl_dist)])
        end
        if errorx < 10^(-5), break, end
   % end
end

function err = nmf_eVclidean_dist(X,Y)

err = sum(sum((X-Y).^2));
