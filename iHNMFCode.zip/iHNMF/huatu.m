
%% �������ͼ��ÿ����������ɫ����ʾ������ ����������������Ч��ͼ
figure(1)
subplot(3,4,5);
title('�ڽӾ���');
X1 = mapminmax(X,0,1);%��һ��
X1(:,1:176)=X1(:,1:176).*10^(4);X1(:,177:574)=X1(:,177:574).*10^(4);X1(:,575:757)=X1(:,575:757).*10^(4);
imagesc(X1);


subplot(3,8,13);
title('�ڽӾ���');
imagesc(U);
colorbar;
subplot(6,4,12);
title('�ڽӾ���');
imagesc(V);
colorbar;
subplot(3,4,3);
title('�ڽӾ���');
X2 = mapminmax(XX,0,1);%��һ��
X2(:,1:176)=X2(:,1:176).*10^(4);X2(:,177:574)=X2(:,177:574).*10^(4);X2(:,575:757)=X2(:,575:757).*10^(4);
imagesc(X2);
colorbar;
%% ����ͼ  ��ά
subplot(212);
hold on;
dotsize = 14;
colors = [1,0,0;
          0,0,1;
          0,1,0;
          0,0.5,0.5;
          0.5,0.5,0;];
C = zeros(3,size(gnd,1));
for i = 1 : size(gnd,1)  
	C(:,i) = colors(gnd(i),:);
end
scatter(X(1,:), X(2,:),dotsize, C', 'SizeData', dotsize); 
axis equal;
title('AC_iNMF data');
%% ����ͼ  ��ά
 view(3)
 plot3(V(1,y==1),V(2,y==1),V(3,y==1),'gx','MarkerSize',8,'LineWidth',1.5);hold on;
 plot3(V(1,y==2),V(2,y==2),V(3,y==2),'r+','MarkerSize',6,'LineWidth',1.5);hold on;
 plot3(V(1,y==3),V(2,y==3),V(3,y==3),'b.','MarkerSize',10,'LineWidth',1.5)
grid on
axis square
%% ��ͼ
figure(1)
boxplot([X1;X2;X3;X4;X5;X6;X7].','symbol','k*','width',.4);
set(gca,'XTickLabel',{'NMF','SNMF','GNMF','RGNMF','CGNMF','Huber-NMF','Huber-SGNMF'});
ylim([0,1]);
set(gca,'LineWidth',1.5);

XX=[0.6984 	0.7151 	0.6951 	0.7186 	0.7381 	0.7253 	0.7552 
0.6395 	0.6533 	0.6192 	0.6445 	0.6674 	0.6709 	0.6902 
0.6134 	0.6245 	0.5767 	0.6280 	0.6447 	0.6382 	0.6556 
0.6417 	0.6379 	0.5907 	0.6349 	0.6551 	0.7253 	0.6717 ];

plot(XX(:,7),'-+');
hold on
plot(XX(:,6),'-.>');
hold on
plot(XX(:,5),'-.<');
hold on
plot(XX(:,4),'-.s');
hold on
plot(XX(:,3),'-.o');
hold on
plot(XX(:,2),'-.*');
hold on
plot(XX(:,1),'-.d');
hold on

set(gca,'XTickLabel',{'ACC','','macro-R','','macro-P','','macro-F'});
legend('Huber-SGNMFNMF','Huber-NMF','CGNMF','RGNMF','GNMF','SNMF','NMF');

%% ��ά����ͼ   result 1��2�ǲ�����3�Ǿ�ȷ��
A = PAAD_ESCA_HNSC;
for i=1:10
    for j=1:11
        result((i-1)*10+j,1)=i;
        result((i-1)*10+j,2)=0.01*(j-1);
        result((i-1)*10+j,3)=A(i,j);
    end
end
x=result(:,1);
y=result(:,2);
z=result(:,3);
figure;
ACC=[x y z];
[x,y]=meshgrid(x,y);

[xx,yy]=meshgrid(-6:1:10,-6:1:10);  %���������
zz=griddata(result(:,1),result(:,2),result(:,3),xx,yy,'v4');%������ݵò�ֵ�����������ݡ�
surf(xx,yy,zz)
shading interp

label1 = {'1','2','3','4','5','6','7', '8','9', '10',};%��ǩ
label2 = {'0.01','0.02','0.03','0.04','0.05','0.06','0.07', '0.08','0.09', '0.1'};%��ǩ


set(gca, 'xticklabel', label1);
set(gca, 'yticklabel', label2);
xlabel('beta');
ylabel('alpha');
zlabel('Accuracy');
title('Influence of parameters on clustering accuracy');

