function [indCluster,Xout,Aout,Yout,numIter,tElapsed,finalResidual]=NMFCluster(X,k,option)
% NMF based clustering
% Usage:
% [indCluster,numIter,tElapsed,finalResidual]=NMFCluster(X) % in this case, X is coefficient matrix obtained by a NMF outside this function
% [indCluster,numIter,tElapsed,finalResidual]=NMFCluster(X,k)
% [indCluster,numIter,tElapsed,finalResidual]=NMFCluster(X,k,option)
% X: matrix, the data to cluster, each column is a sample/data point
% k: the number of clusters
% option: struct, 
% option.reorder, logical scalar, if to reorder the data points based on
% clustering result, the default is true
% the rest fields of option is the same as the option in the nmf function, type "help nmf" for more informtion
% indCluster: the cluster label of each sample, i.e. indCluster=[2;2;1;1;3;2;1;1;2;3];
% numIter: scalar, the number of iterations.
% tElapsed: scalar, the computing time used.
% finalResidual: scalar, the fitting residual.
%
% Yifeng Li
% University of Windsor
% li11112c@uwindsor.ca; yifeng.li.cn@gmail.com
% May 21, 2011
%%%%

callNMF=true;
if nargin==2
    option=[];
    callNMF=true;
end
if nargin==1
    Y=X; % X is coefficient matrix
    A=[];
    callNMF=false;
    option=[];
end
optionDefault.reorder=true;
optionDefault.algorithm='nmfnnls';
optionDefault.optionnmf=[];
option=mergeOption(option,optionDefault);

if nargin==1
    Y=X; % X is coefficient matrix
    callNMF=false;
end
if callNMF
      [A,Y] = NMF_ed(X,k,200,0);
end
[C,indCluster] = max(Y,[],1);
indCluster=indCluster';
Xout=[];
Aout=[];
Yout=[];
if option.reorder
    [indClusterSorted,ind]=sort(indCluster);
    Xout=X(:,ind);
    Yout=Y(:,ind);
    Aout=A;
end
end
function [A,Y,numIter,tElapsed,finalResidual]=nmfnnls(X,k,option)
% NMF based on NNLS: X=AY, s.t. X,A,Y>=0.
% Definition:
%     [A,Y,numIter,tElapsed,finalResidual]=nmfnnls(X,k)
%     [A,Y,numIter,tElapsed,finalResidual]=nmfnnls(X,k,option)
% X: non-negative matrix, dataset to factorize, each column is a sample, and each row is a feature.
% k: scalar, number of clusters.
% option: struct:
% option.iter: max number of interations. The default is 1000.
% option.dis: boolen scalar, It could be 
%     false: not display information,
%     true: display (default).
% option.residual: the threshold of the fitting residual to terminate. 
%     If the ||X-XfitThis||<=option.residual, then halt. The default is 1e-4.
% option.tof: if ||XfitPrevious-XfitThis||<=option.tof, then halt. The default is 1e-4.
% A: matrix, the basis matrix.
% Y: matrix, the coefficient matrix.
% numIter: scalar, the number of iterations.
% tElapsed: scalar, the computing time used.
% finalResidual: scalar, the fitting residual.
% References:
%  [1]\bibitem{NMF_ANLS_Kim2008}
%     H. Kim and H. Park,
%     ``Nonnegative matrix factorization based on alternating nonnegativity constrained least squares and active set method,''
%     {\it SIAM J. on Matrix Analysis and Applications},
%     vol. 30, no. 2, pp. 713-730, 2008.
%  [2]\bibitem{NMF_Sparse_Kim2007}
%     H. Kim and H. Park,
%     ``Sparse non-negatice matrix factorization via alternating non-negative-constrained least squares for microarray data analysis,''
%     {\it Bioinformatics},
%     vol. 23, no. 12, pp. 1495-1502, 2007.
%%%%
% Copyright (C) <2012>  <Yifeng Li>
% 
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.
% 
% Contact Information:
% Yifeng Li
% University of Windsor
% li11112c@uwindsor.ca; yifeng.li.cn@gmail.com
% May 01, 2011
%%%%

tStart=tic;
optionDefault.iter=200;
optionDefault.dis=true;
optionDefault.residual=1e-4;
optionDefault.tof=1e-4;
if nargin<3
   option=optionDefault;
else
    option=mergeOption(option,optionDefault);
end

% iter: number of iterations
[r,c]=size(X); % c is # of samples, r is # of features
Y=rand(k,c);
XfitPrevious=Inf;
for i=1:option.iter
    A=kfcnnls(Y',X');
    A=A';
    A=normc(A);
    Y=kfcnnls(A,X);
    if mod(i,20)==0 || i==option.iter
        if option.dis
            disp(['Iterating >>>>>> ', num2str(i),'th']);
        end
        XfitThis=A*Y;
        fitRes=matrixNorm(XfitPrevious-XfitThis);
        XfitPrevious=XfitThis;
        curRes=norm(X-XfitThis,'fro');
        if option.tof>=fitRes || option.residual>=curRes || i==option.iter
            s=sprintf('NNLS based NMF successes! \n # of iterations is %0.0d. \n The final residual is %0.4d.',i,curRes);
            disp(s);
            numIter=i;
            finalResidual=curRes;
            break;
        end
    end
end
tElapsed=toc(tStart);
end


function optionFinal=mergeOption(option,optionDefault)
% Merge two struct options into one struct
% % 
% Contact Information:
% Yifeng Li
% University of Windsor
% li11112c@uwindsor.ca; yifeng.li.cn@gmail.com
% Mar. 18, 2011
%%%%

optionFinal=optionDefault;
if isempty(option)
    return;
end
names=fieldnames(option);
for i=1:numel(names)
    optionFinal=setfield(optionFinal,names{i},getfield(option,names{i}));
end
end