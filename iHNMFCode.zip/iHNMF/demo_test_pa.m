clear all
load('F:\TCGA\PAAD\PAAD_GE_comData');
load('F:\TCGA\PAAD\PAAD_ME_comData');
load('F:\TCGA\PAAD\PAAD_CN_comData');
load('F:\TCGA\PAAD\PAAD_sampleCategory1');
addpath('E:\MXH\jNMF\MDmodule.toolbox\clustering');
X1 = mapminmax(PAAD_GE_comData, 0, 1);
X2 = mapminmax(PAAD_ME_comData, 0, 1);
X3 = mapminmax(PAAD_CN_comData, 0, 1);
sample_of_all = Samplecategory;
nclass = size(unique(sample_of_all),1);
% K = [1,2,3,4,5,6,7,8,9,10,20,30,40,50,100,200,300,400]; 
%K = [1,2,3,4,5,6,7,8,9,10,20,30,40]; 
K = [5,10,20,30,40,50,60,70,80,90,100,120,150,180]; 
%K = [1,2,3,4,5,6,7,8,9,10,20,30,40,50,80,100,150,180,200,230,250,270]; 
n = size(K,2);
tic
for i = 1 : n
maxiter = 100;
speak = 0; 
[W,H1,H2,H3,errorx]=TriNMF_mm(X1, X2, X3, K(i), maxiter, speak);
%��W����������
label = NMFCluster( W,nclass);
res = bestMap(sample_of_all,label);
AC{i}(1) = length(find(sample_of_all == res))/length(sample_of_all);
AC{i}(2) = errorx;
%��W�ǻ������
% label1 = kmeans( H1',nclass);
% res = bestMap(sample_of_all,label1);
% AC(i,1) = length(find(sample_of_all == res))/length(sample_of_all);
% label2 = kmeans( H2',nclass);
% res = bestMap(sample_of_all,label2);
% AC(i,2) = length(find(sample_of_all == res))/length(sample_of_all);
% label3 = kmeans( H3',nclass);
% res = bestMap(sample_of_all,label3);
% AC(i,3) = length(find(sample_of_all == res))/length(sample_of_all);
% AC(i,4) = (AC(i,1)+AC(i,2)+AC(i,3))/3;
% AC(i,5) = errorx;
% AC(i,6) = K(i);
end
toc
%% ======iGNMF==============
tic
maxiter = 100;
speak = 0; 
for i = 1 : n
  for j = 1 : 20
p.lamda1 = 0.01;
p.lamda2 = 0.01;
p.lamda3 = 0.01;
options.NeighborMode = 'KNN';
options.k = 5;
options.WeightMode = 'Binary';  
options.t = 1;
W1 = constructW(X1',options); 
W2 = constructW(X2',options); 
W3 = constructW(X3',options); 
[V,U1,U2,U3,errorx] = iHNMF(X1, X2, X3, K(i), maxiter, speak, p);
%��W����������
label = kmeans(V,nclass);
res = bestMap(sample_of_all,label);
AC(i,j) = length(find(sample_of_all == res))/length(sample_of_all);
%��V�ǻ������
% label1 = kmeans( U1,nclass);
% res = bestMap(sample_of_all,label1);
% AC(i,1) = length(find(sample_of_all == res))/length(sample_of_all);
% label2 = kmeans( U2,nclass);
% res = bestMap(sample_of_all,label2);
% AC(i,2) = length(find(sample_of_all == res))/length(sample_of_all);
% label3 = kmeans( U3,nclass);
% res = bestMap(sample_of_all,label3);
% AC(i,3) = length(find(sample_of_all == res))/length(sample_of_all);

% AC(i,4) = (AC(i,1)+AC(i,2)+AC(i,3))/3;
% AC(i,5) = errorx;
% AC(i,6) = K(i);
    end
    AC(i,j+1) = mean(AC(i,1:20));
    AC(i,j+2) = K(i);
end
toc
maxiter = 1000;
for i = 1 : 50
p.lamda1 = 0.01;
p.lamda2 = 0.01;
p.lamda3 = 0.01;
options.NeighborMode = 'KNN';
options.k = 5;
options.WeightMode = 'Binary';  
options.t = 1;
W1 = constructW(X1',options); 
W2 = constructW(X2',options); 
W3 = constructW(X3',options); 
[V,U1,U2,U3,errorx] = iGNMF(X1, X2, X3, W1, W2, W3, 5, maxiter, 0, p);

label1 = NMFCluster(V,nclass);
res = bestMap(sample_of_all,label1);
AC_iGNMF(i) = length(find(sample_of_all == res))/length(sample_of_all);


[W_j,H1,H2,H3,errorx] = TriNMF_mm(X1', X2', X3', 5, maxiter, 0);
label2 = kmeans(W,nclass);
res = bestMap(sample_of_all,label2);
AC_iNMF(i) = length(find(sample_of_all == res))/length(sample_of_all);
end
%% ����������
p.lamda1 = 0.01;
p.lamda2 = 0.01;
p.lamda3 = 0.01;
options.NeighborMode = 'KNN';
options.k = 50;
options.WeightMode = 'Binary';  
options.t = 1;
W1 = constructW(X1,options); 
W2 = constructW(X2,options); 
W3 = constructW(X3,options); 
[W_V,U1,U2,U3,errorx_iGNMF] = iGNMF(X1', X2', X3', W1, W2, W3, 40, maxiter, 0, p);

[W_j,H1,H2,H3,errorx_jNMF] = TriNMF_mm(X1, X2, X3, 5, maxiter, 0);
[W_i,H1,H2,H3,errorx_iNMF] = iNMF(X1, X2, X3, 5, maxiter, 1000, 0);
[W_o,H1,H2,H3,errorx_ioNMF] = ioNMF(X1', X2', X3', 0.01, 5, maxiter, 0);
%% ======figure==============
% plot(PAAD_AC(:,4),'-.sk')
% hold on
% plot(PAAD_AC(:,5),'-.>r')
% set(gca,'xticklabel',K);
%% ��ͼ
save erro_PAAD errorx_iG errorx_iN errorx_jN errorx_io
 plot(errorx_iG,'-.sk')
 hold on
 plot(errorx_iN,'r*')
 hold on
 plot(errorx_jN,'g*')
 hold on
 plot(errorx_io,'b*')
   
   