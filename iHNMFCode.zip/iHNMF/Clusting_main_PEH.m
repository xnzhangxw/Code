clear all
%%%PAAD_ESCA_HNSC������
load('E:\data\PCA_PAAD_ESCA_HNSC_U2.mat')
load('E:\������\data\PCA��ά_���ְ�֢\PAAD_ESCA_HNSC_samplecategory1_19876_Tumor.mat');
X1 = mapminmax(PCA_GE, 0, 1);
X2 = mapminmax(PCA_ME, 0, 1);
X3 = mapminmax(PCA_CN, 0, 1);
sample_of_all = PAAD_ESCA_HNSC_samplecategory1_19876_Tumor;
nclass = size(unique(sample_of_all),1);
r=6;
num = 50;
maxiter = 200;

p.lamda1 = 0.2;
p.lamda2 = 0.2;
p.lamda3 = 0.2;
options.NeighborMode = 'KNN';
options.k = 5;
options.WeightMode = 'Binary'; 
options.t = 1;

%%%-----iHNMF-----
tic
[De1,Dv1,W1,H1,L1] =ConstructH(X1');
De1H1 = (De1^-1) * H1';
W1De1H1 = W1 * De1H1;
F1 = H1 * W1De1H1;
[De2,Dv2,W2,H2,L2] =ConstructH(X2');
De2H2 = (De2^-1) * H2';
W2De2H2 = W2 * De2H2;
F2 = H2 * W2De2H2;
[De3,Dv3,W3,H3,L3] =ConstructH(X3');
De3H3 = (De3^-1) * H3';
W3De3H3 = W3 * De3H3;
F3 = H3 * W3De3H3;

for i = 1 : num
[F,B1,B2,B3,errorx1] = iHNMF(X1, X2, X3, F1, F2, F3, Dv1, Dv2, Dv3, r, maxiter, 0, p);
label1 = kmeans(F,nclass);
% %label1 = NMFCluster(V',nclass);
[AC_iHNMF(i),MI_iHNMF(i),recall_iHNMF(i), precision_iHNMF(i), Fmeasure_iHNMF(i)] = Accary_duo(F',sample_of_all);
NMI_iHNMF(i) = Cal_NMI(sample_of_all,label1);
end
NMI_iHNMF_mean = mean(NMI_iHNMF);
AC_iHNMF_mean = mean(AC_iHNMF);
recall_iHNMF_mean = mean(recall_iHNMF);
precision_iHNMF_mean = mean(precision_iHNMF);
Fmeasure_iHNMF_mean = mean(Fmeasure_iHNMF);
t_iHNMF=toc


%%-----jNMF-----
tic
for i = 1 : num
[W_j,H1,H2,H3,errorx2] = TriNMF_mm(X1', X2', X3', r, maxiter, 0);
label2 = kmeans(W_j,nclass);
% %labe2 = NMFCluster(W_j',nclass);
[AC_jNMF(i),MI_jNMF(i),recall_jNMF(i), precision_jNMF(i), Fmeasure_jNMF(i)] = Accary_duo(W_j,sample_of_all);
NMI_jNMF(i) = Cal_NMI(sample_of_all,label2);
end
NMI_jNMF_mean = mean(NMI_jNMF);
AC_jNMF_mean = mean(AC_jNMF);
recall_jNMF_mean = mean(recall_jNMF);
precision_jNMF_mean = mean(precision_jNMF);
Fmeasure_jNMF_mean = mean(Fmeasure_jNMF);
t_jNMF = toc




%%------iNMF-----
tic
for i = 1 : num
[W_i,H1,H2,H3,errorx3] = iNMF(X1', X2', X3', r, maxiter, 1000, 0);
label3 = kmeans(W_i,nclass);
% %label3 = NMFCluster(W_i',nclass);
[AC_iNMF(i),MI_iNMF(i),recall_iNMF(i), precision_iNMF(i), Fmeasure_iNMF(i)] = Accary_duo(W_i,sample_of_all);
NMI_iNMF(i) = Cal_NMI(sample_of_all,label3);
end
NMI_iNMF_mean = mean(NMI_iNMF);
AC_iNMF_mean = mean(AC_iNMF);
recall_iNMF_mean = mean(recall_iNMF);
precision_iNMF_mean = mean(precision_iNMF);
Fmeasure_iNMF_mean = mean(Fmeasure_iNMF);
t_iNMF = toc


%%-----ioNMF-----
tic
for i = 1 : num
[W_o,H1,H2,H3,errorx] = ioNMF(X1', X2', X3', 0.01, r, maxiter, 0);
label4 = kmeans(W_o,nclass);
% %label4 =NMFCluster(W_o',nclass);
[AC_ioNMF(i),MI_ioNMF(i),recall_ioNMF(i), precision_ioNMF(i), Fmeasure_ioNMF(i)] = Accary_duo(W_o,sample_of_all);
NMI_ioNMF(i) = Cal_NMI(sample_of_all,label4);
end
NMI_ioNMF_mean = mean(NMI_ioNMF);
AC_ioNMF_mean = mean(AC_ioNMF);
recall_ioNMF_mean = mean(recall_ioNMF);
precision_ioNMF_mean = mean(precision_ioNMF);
Fmeasure_ioNMF_mean = mean(Fmeasure_ioNMF);
t_ioNMF = toc







%% ======figure==============
% plot(HNSC_AC(:,4),'-.sk')
% hold on
% plot(HNSC_AC(:,5),'-.>r')
% set(gca,'xticklabel',K);

