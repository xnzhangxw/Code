function [AC,MIhat,recall, precision, Fmeasure] = Accary_duo(V,gnd)
nClass = length(unique(gnd));
label = kmeans(V,nClass);
res = bestMap(gnd,label);
%=============  evaluate AC: accuracy ==============
AC = length(find(gnd == res))/length(gnd);
MIhat = MutualInfo(gnd,label);%�жϾ���Ч��
% disp(['Clustering in the HNMF AC and MI: ',num2str(AC), ',' , num2str(MIhat)]);
[recall, precision, Fmeasure]=Value_duo(gnd,res);
end
