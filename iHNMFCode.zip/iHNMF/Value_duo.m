function [recall, precision, Fmeasure]=Value_duo(gnd,label)
[m,n] = size(gnd);
nclass = size(unique(gnd),1);
count=zeros(nclass,nclass);
ii=1;
gnd(m+1)=0;
for i=1:m
    count(gnd(i),label(i))= count(gnd(i),label(i))+1;
%     if ii~= gnd(i+1)
%         ii=ii+1;
%     end
end
lie=sum(count,1);
hang=sum(count,2);
for i=1:nclass
    recall(i)=count(i,i)/lie(i);
    precision(i)=count(i,i)/hang(i);
end
    recall=mean(recall);
    precision=mean(precision);
    Fmeasure = 2/(1/precision + 1/recall);
end



        
